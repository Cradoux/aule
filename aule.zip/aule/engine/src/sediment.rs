//! Sediment transport/deposition helpers (T-101 placeholder).
//!
//! The MVP surface orchestrator implements single-receiver routing and capacity-controlled
//! deposition internally. This module remains as a placeholder for future enhancements.
